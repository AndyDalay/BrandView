import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';

export function Header({ children }: { children?: ReactNode }) {
  return (
    <header className="relative z-10 flex h-[72px] items-center justify-between gap-4 border-b border-gris-line bg-white/60 px-5 backdrop-blur md:px-10">
      <Link to="/" aria-label="Ir a la galería" className="flex items-center">
        <img src="/brand/andybrand-logo.png" alt="Andy Brand" width={52} height={32} className="h-8 w-auto select-none" draggable={false} />
      </Link>
      {children}
    </header>
  );
}
