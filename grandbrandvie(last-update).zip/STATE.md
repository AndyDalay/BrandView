# Estado del Proyecto — GrandBrandView

> **Claude: lee esto primero.** Es tu memoria entre sesiones. Actualízalo al final de cada respuesta.

---

## 📍 Dónde estamos

- **Sesión:** Planificación de **Comentarios con audio + transcripción** (nueva tarea principal). Header, modal de borrado, controles y sombras del visor **cerrados**.
- **Rama:** `diseno`.
- **Flujo de ramas:** `diseno` → `dev` → `produccion`. Vercel publica `produccion`; `dev` y `diseno` generan previews.
- **Puerto de desarrollo:** `3000` fijo (Figma Make y Playwright lo necesitan).
- **Supabase:** cliente único en `src/lib/supabase.ts`, reexportado en `src/lib/supabaseClient.ts`. Variables: `VITE_SUPABASE_URL` y `VITE_SUPABASE_PUBLISHABLE_KEY`.
- **Pendiente de verificación:** suite E2E en firefox/webkit/mobile; lockfile en CI.

---

## ✅ Qué está hecho

**Galería y visor (app)**
- Galería con arrastre para reordenar (ratón, táctil, teclado Alt+flechas).
- Borrado de manuales (locales en IndexedDB; base ocultables) con modal propio de la app (`ConfirmDeleteModal`, sin `window.confirm`).
- Header solo con logo (desktop y móvil).
- Visor de libro: giro de páginas, portada/contraportada centradas, apertura lenta.
- Visor, controles: mantener pulsado ◀ / ▶ pasa páginas (acelera tras 1,5 s); tocar "3 / 8" permite escribir la página (`page-input`).
- Visor, sombras: sombra de los bordes y franja del lomo animadas solo en giros de portada/contraportada, sincronizadas con el aterrizaje (80–88 % del tiempo). Verificado por el usuario.
- Visor, dobles páginas: en 8/9 la contraportada ocupa el lado derecho; sin papel en blanco estático.
- Compartir: publica en Supabase con sesión anónima; botones WhatsApp, Telegram y correo.

**Flujo de trabajo (Tarea 1)**
- `vite.config.ts`: puerto 3000, `strictPort`, `host`, y alias `@` → `src`.
- `tsconfig.json`: `paths` para `@/*`, así `@/lib/supabaseClient` resuelve.
- `src/lib/supabaseClient.ts`: reexporta el cliente de `src/lib/supabase.ts`. No crea un segundo cliente.
- `package.json`: scripts `lint` (sin `--ext`, que no existe en ESLint 9), `test:e2e` y relacionados; devDependencies `@playwright/test`, `dotenv`, `eslint`, `@eslint/js`, `typescript-eslint`, `eslint-plugin-react-hooks`, `eslint-plugin-react-refresh`, `globals`.
- `eslint.config.js`: configuración plana de ESLint 9.
- `.github/workflows/ci.yml`: ramas `[produccion, dev, diseno]`, usa `VITE_SUPABASE_PUBLISHABLE_KEY`.
- `.claude/SKILL.md`, `.cursor/rules`, `TUTORIAL.md`, `COMMANDS.md`: referencias a `main` sustituidas por el flujo `diseno → dev → produccion`.
- `.gitignore`: `playwright-report`, `test-results`, `.env.test`.

**Tarea 2 — tests y data-testid**
- `data-testid` en galería (`library-page`, `gallery`, `add-manual-button`, `manual-card`, `manual-delete`), visor (`share-button`, `sound-toggle`, `fullscreen-button`, `back-button`), libro (`book-viewer`, `page-indicator`, `prev-page`, `next-page`) y modal (`share-modal`, `share-close`, `share-link`, `share-whatsapp`, `share-telegram`, `share-correo`).
- Tests: `library.spec.ts`, `viewer.spec.ts`, `share.spec.ts`. Eliminados: `home.spec.ts`, `supabase.spec.ts`, `visual.spec.ts` y `HomePage.ts` (eran de la plantilla).
- Script `test:snapshots` eliminado de `package.json`.
- **Chromium (2026-11-07):** `library.spec.ts` 2/2, `viewer.spec.ts` 3/3, `share.spec.ts` 1/1. Hang del visor: `preloadImages()`; timeout de 5 s con `Promise.race`.
- **Lint / tipos (2026-11-07):** `npm run lint` exit 0 (max-warnings 0). `npx tsc --noEmit` exit 0.

**Limpieza de lint (opción 1)**
- `src/lib/masonryLayout.ts` (nuevo): `layoutHorizontal` y los tipos `Pin`, `PlacedPin`, `Lane`. Ya no vive en el componente.
- `src/components/HorizontalMasonry.tsx`: importa esas funciones y reexporta los tipos, así `Library.tsx` no cambia.
- `src/lib/transitionContext.ts` (nuevo): contexto de transición.
- `src/lib/useTransition.ts` (nuevo): hook `useTransition`.
- `src/lib/transition.tsx`: solo `TransitionProvider`.
- `src/pages/Library.tsx` y `src/pages/Viewer.tsx`: importan `useTransition` desde `useTransition.ts`.
- `.env.example`: ya usaba `VITE_SUPABASE_PUBLISHABLE_KEY`; sin cambios.

---

## 🔄 En progreso

- Tarea activa: **Cuentas y perfiles (prerrequisito)** y después **Comentarios con audio y transcripción**. Ver secciones dedicadas abajo. Responsive 360×800 queda en pausa.

---

## 📋 Pendiente (orden de prioridad)

1. ~~**Header:** quitar el texto "GRANDBRANDVIEW", dejar solo el logo.~~ **HECHO.**
2. **Lockfile:** confirmar que `package-lock.json` incluye Playwright/ESLint y está listo para `npm ci` del CI (no se ha hecho commit).
3. **Tests E2E restantes:** firefox, webkit y mobile (`npm run test:e2e`). Chromium ya cubre galería, visor y compartir.
   - [x] **Escrito (Tarea 3):** borrado en galería (`tests/e2e/delete.spec.ts`): cancelar, Escape, confirmar en manual local (siembra IndexedDB).
   - [x] **Escrito (Tarea 3):** controles del visor (`tests/e2e/viewer-controls.spec.ts`): page-indicator → page-input, número válido + Enter, número mayor que el total, mantener pulsado next-page.
   - [ ] **Pendiente de ejecutar en Chromium:** `npx playwright test tests/e2e/delete.spec.ts tests/e2e/viewer-controls.spec.ts --project=chromium`. Sin resultados todavía: no se ha podido correr aquí.
4. **Supabase Auth:** añadir `http://localhost:3000/**` a Redirect URLs (lo hace el usuario en el panel).

### Tareas posteriores (cada una en su propia sesión)

- Revisión responsive 360×800 (en pausa; ver Tareas posteriores).
- Botón "Quitar anuncios" con modal (ver vídeo o donar para 1 año) y visor a pantalla completa con horizontal en móvil.
- Imagen OG por manual (requiere función de servidor).
- Comentarios con audio y transcripción Whisper (requiere backend).
- Revisión responsive 360×800 (en pausa).
- Cuentas y perfiles: P1–P9 (ver sección dedicada).
- Monetización: AdSense (decidido). PayPal: pendiente.

---

---

## 👤 Prerrequisito: cuentas, perfiles y avatar

### Objetivo
Iniciar sesión con Google, gestionar la cuenta y editar el perfil (nombre y foto). La foto se recorta en un cuadrado con una guía circular y se optimiza antes de subirla. El avatar aparece en el header (`photo-user-container`) y en las lágrimas de comentarios.

### Decisiones de arquitectura (propuestas, confirmar antes de P1)
| Tema | Propuesta | Por qué |
|---|---|---|
| Login | Google vía Supabase Auth (proveedor OAuth) | Sin contraseñas. El usuario lo configura en Google Cloud y Supabase (ver prompt). |
| Sesión anónima actual | Vincular la identidad de Google al usuario anónimo con `linkIdentity` (mismo ID) | Mantiene manuales compartidos y comentarios ya creados. **Riesgo: probar en un caso real antes de dar por cerrado.** Si el ID cambia, habrá que migrar `owner_id`. |
| Perfil | Tabla `perfiles` (`id` = auth.uid, `nombre`, `avatar_path`, `avatar_version`, `updated_at`). RLS: leer público, escribir solo el propio | Nombre y foto visibles para comentarios sin exponer el email. |
| Imagen | Recorte cuadrado en el navegador, salida de 256 px (perfil) y 96 px (miniatura), WebP con respaldo JPEG, máx. ~80 KB | Sin transformaciones de Supabase en plan gratuito: optimizamos antes de subir. |
| Almacenamiento | Bucket `avatares` público en lectura; escritura solo en `uid/…` del propio usuario | La URL pública es cacheable; el versionado (`avatar_version`) evita caché vieja al cambiar foto. |
| Cuenta | Página `/cuenta`: datos, editar nombre, cambiar foto, cerrar sesión. Borrar cuenta: fase posterior (requiere función de servidor) | Alcance controlado. |

### Requisitos de producto
1. Botón "Iniciar sesión con Google" visible en el header cuando no hay cuenta. Con cuenta: avatar en `photo-user-container` que abre el menú de cuenta.
2. Editar perfil: nombre (2–40 caracteres, validado) y foto.
3. **Recortador de foto** (modal):
   - Cuadrado de recorte con bordes y esquinas marcados.
   - Zona circular central dentro del cuadrado (máscara oscura fuera del círculo) que muestra exactamente cómo quedará el avatar.
   - El usuario arrastra la **foto** debajo del cuadro para encuadrarla. El cuadro no se mueve ni cambia de tamaño.
   - Zoom opcional con deslizador (o rueda en escritorio), con límites para que la foto siempre cubra el círculo.
   - Botón "Subir" → recorta, optimiza y sube. Botón "Cancelar" descarta.
4. Vista previa en vivo del círculo final mientras se encuadra.
5. Estado de carga y error claro (archivo no válido, demasiado pesado, sin conexión).
6. Avatar en comentarios y header usa la misma versión de 96 px; la de 256 px solo en la página de cuenta.

### Microanimaciones y diseño
- Recortador: la máscara oscura se aclara suavemente al empezar a arrastrar; el círculo tiene un borde fino de la marca que pulsa una vez al soltar.
- Avatar: entrada con fade + escala leve; al cambiar la foto, cross-fade de la anterior a la nueva.
- Botón "Subir": estado de carga con anillo azul; al terminar, pequeño check y cierre suave.
- Respeta `prefers-reduced-motion`.

### Subtareas
- [ ] **P1 — Configuración de Google (lo hace el usuario):** Google Cloud (cliente OAuth, URI de redirección de Supabase) y proveedor Google en Supabase. Documentar pasos en `docs/google-login.md`.
- [ ] **P2 — Login y vinculación:** `src/lib/auth.ts`: iniciar sesión con Google, vincular la sesión anónima, cerrar sesión, estado de sesión global. Prueba manual obligatoria: un manual compartido antes del login sigue siendo del mismo usuario después.
- [ ] **P3 — Base de datos:** migración `0004_perfiles.sql` (tabla `perfiles`, trigger de creación, RLS) y bucket `avatares` con políticas.
- [ ] **P4 — Procesado de imagen:** `src/lib/avatarImage.ts`: validar tipo y tamaño, recortar a cuadrado según el encuadre, redimensionar a 256 y 96 px, codificar WebP con respaldo JPEG, comprobar peso.
- [ ] **P5 — Recortador:** componente `AvatarCropper` (modal) con cuadro, máscara circular, arrastre de la foto, zoom, vista previa y accesibilidad (teclado para mover y hacer zoom).
- [ ] **P6 — Subida y perfil:** `src/lib/perfiles.ts`: subir ambas versiones, actualizar `avatar_path` y `avatar_version`, guardar nombre.
- [ ] **P7 — Componente `UserAvatar`:** un solo componente para header, comentarios y cuenta, con inicial de respaldo y tamaños.
- [ ] **P8 — Página `/cuenta`:** datos, editar nombre, cambiar foto, cerrar sesión. Ruta protegida: si no hay sesión, redirige al login.
- [ ] **P9 — Tests E2E:** flujo del recortador (abrir, arrastrar, subir con imagen de prueba), y el avatar visible tras recargar. Login real de Google no se prueba en CI: mockear la sesión.

### Riesgos
- **Vinculación anónima → Google:** es la parte más delicada. Si no conserva el ID, los manuales y comentarios previos quedan huérfanos. Probar antes de P3.
- **Fotos grandes o HEIC:** iOS puede enviar HEIC. Convertir o rechazar con mensaje claro.
- **Privacidad:** el avatar es público. Informar en la pantalla de edición.
- **Plan gratuito de Supabase:** límites de almacenamiento y de ancho de banda; las miniaturas de 96 px mantienen el consumo bajo.

---

## 🎙️ Tarea activa: Comentarios con audio y transcripción

### Objetivo
Un espectador puede dejar comentarios anclados a una página del manual. Cada comentario es una **lágrima** pequeña con avatar del autor. Puede escribirlo o grabarlo; el audio se transcribe con Whisper en el servidor y el texto queda guardado aunque el usuario salga, cambie de página o vuelva otro día.

### Decisiones de arquitectura (propuestas, confirmar antes de T1)
| Tema | Propuesta | Por qué |
|---|---|---|
| Transcripción | **Groq** (whisper-large-v3-turbo) como principal; **Hugging Face** Inference como respaldo | Rápidos y con capa gratuita. El modelo ya vive en su servidor: no hay nada que precargar en el cliente. |
| Dónde corre | Función serverless en `api/` (Vercel) | Oculta las claves y se despliega con `produccion`. |
| Estado del trabajo | Columna `estado` en `comentarios`: `pendiente → transcribiendo → listo / error` | El proceso corre en servidor; al volver, el cliente lee el estado. |
| Audio | MediaRecorder, `audio/webm;codecs=opus` (o `audio/mp4` en Safari), máx. 60 s, máx. 2 MB | Cabe en el límite de la función; Safari necesita detectar el formato. |
| Almacenamiento | Bucket `comentarios` (Storage), ruta `manual/pagina/uuid.webm`; RLS: insertar solo con sesión | Reutiliza la sesión anónima ya existente. |
| Posición | Página (índice de la página del manual) + `x`, `y` normalizados 0–1 | Se ve bien en cualquier tamaño de pantalla. |
| Voz (texto → audio) | 1.º Web Speech API del navegador (gratis, sin clave). 2.º opcional: TTS de Hugging Face | No depende de una clave para funcionar. |
| Avatar | Inicial + color por defecto. Foto real solo si hay login con proveedor | La sesión anónima no tiene foto. **Decisión abierta.** |
| Precarga de Whisper | **No aplica** con API hospedada. Si más adelante se quiere modelo propio, sería una función con modelo caliente (Modal, Hugging Face Spaces o similar), no Vercel gratuito | Honestidad técnica: el backend gratuito de Vercel no puede mantener un modelo cargado. |

### Requisitos de producto
1. Modo colocar: tocar la página añade una lágrima en ese punto (con la página visible).
2. Lágrima: forma de gota, avatar pequeño del autor, sombra suave. Tooltip con nombre y fecha al pasar.
3. Al lado de la lágrima, una burbuja con icono de micrófono para grabar.
4. Grabación: onda en vivo con barras verticales redondeadas que reaccionan al volumen. Botón para detener. Cancelar descarta.
5. Al detener: la lágrima se fija con spinner de carga mientras sube el audio y se transcribe.
6. Al terminar: el texto aparece en el comentario. Si falla, estado de error con botón reintentar.
7. Persistencia: los comentarios se leen de Supabase al abrir el manual; el estado `transcribiendo` se reconsulta al volver.
8. Expandir la lágrima: panel con texto, autor, fecha, botón ▶ para el audio original y botón "Leer en voz alta" (TTS).
9. Permisos de micrófono denegados: mensaje claro, sin romper el visor.

### Microanimaciones y diseño (misma línea visual que el visor)
- Lágrima: entrada con rebote suave (spring), pulso lento mientras está pendiente.
- Burbuja de micro: halo que respira al grabar; color terracota en grabación.
- Onda: barras redondeadas con altura según el volumen, transición de 80 ms.
- Spinner de transcripción: anillo de trazo fino con el color azul de la marca.
- Panel expandido: escala + fade desde la lágrima; cierre con Escape.
- Todo respeta `prefers-reduced-motion`.
- Tipografía: `font-display` para títulos, `font-label` para etiquetas, mismos tokens de color.

### Dependencias
- Requiere P7 (`UserAvatar`) y P2 (sesión con identidad) antes de T4. Hasta entonces, el comentario muestra la inicial y el nombre escrito.

### Subtareas
- [ ] **T1 — Base de datos y storage:** migración `0003_comentarios.sql` (tabla `comentarios`, bucket `comentarios`, RLS). Sin tocar UI.
- [ ] **T2 — API de transcripción:** `api/transcribir.ts` (Vercel). Recibe `comentario_id`, lee el audio de Storage, llama a Groq (fallback HF), guarda texto y estado. Errores tipados y reintentos. Claves solo en variables de entorno del servidor.
- [ ] **T3 — Capa de datos del cliente:** `src/lib/comentarios.ts` (listar por manual, crear, subir audio, disparar transcripción, reconsultar estado).
- [ ] **T4 — Modo colocar y lágrimas:** marcadores sobre las páginas del visor, coordenadas normalizadas, `data-testid` (`comment-pin`, `comment-add-mode`).
- [ ] **T5 — Grabación:** burbuja de micro, MediaRecorder, onda en vivo, cancelar/detener, detección de formato, errores de permiso.
- [ ] **T6 — Estados y transcripción:** pendiente/transcribiendo/listo/error en la lágrima; reconsulta al volver; reintentar.
- [ ] **T7 — Panel expandido:** texto, ▶ audio original, leer en voz alta (Web Speech), cierre.
- [ ] **T8 — Microanimaciones, accesibilidad y móvil:** reduced motion, foco con teclado, 360×800.
- [ ] **T9 — Tests E2E** (Cursor/Playwright): crear comentario de texto, marcador visible tras recargar, panel expandido. La transcripción real no se prueba en CI: se mockea la API.

### Riesgos
- **Claves expuestas:** las claves de Hugging Face y Groq se pegaron en el chat. **Rotarlas antes de T2.**
- **Abuso:** cualquiera con el enlace puede comentar. Limitar tamaño, duración y frecuencia; moderación más adelante.
- **Límite de la capa gratuita:** Groq y HF tienen cuotas. Mostrar error claro si se agotan.
- **Safari y formatos:** probar grabación en iOS antes de dar por cerrado T5.
- **Extensión de WhatsApp:** se usa solo como referencia de código. No se edita ni se copian claves de ella.

## 🐛 Problemas conocidos

- Precarga del visor: Chrome limita conexiones concurrentes; páginas `09.jpg`–`39.jpg` de `manuales/local-mw4iy7lo-bvj7k/` y `/ads/banner-add-01.svg` + `banner-add-02.svg` quedan pending. Mitigado con timeout de 5 s en `preloadImages()` (el libro puede mostrarse antes de que todas las páginas estén en caché).
- La consulta `GET .../rest/v1/manuales` llegó a tardar ~16 s en la traza; puede hacer flaky el `beforeEach` si se acerca al timeout de 30 s.
- Visor (sombras): verificado por el usuario en escritorio. Pendiente de revisar en móvil, porque el visor en móvil no usa la franja del lomo ni las sombras animadas.
- Escape con modal ocupado (borrando) no está cubierto por tests: el estado `busy` no se puede forzar de forma fiable sin un mock de red.
- El test de mantener pulsado depende de la duración del giro; por eso solo comprueba que se avanzan más de 2 páginas.
- Las claves de Hugging Face y Groq se han pegado en el chat: deben rotarse y guardarse como variables de entorno en el backend.

---

## 🗺️ Decisiones tomadas

| Decisión | Por qué |
|---|---|
| Ramas `diseno` → `dev` → `produccion` | Así está configurado en GitHub y Vercel. |
| Puerto 3000 fijo | Figma Make y Playwright lo necesitan. |
| `BrowserRouter` | Rutas limpias para `/manual/:id`. |
| Cliente Supabase único | Evita instancias duplicadas; la skill importa desde `@/lib/supabaseClient`. |
| Sesión anónima para compartir | Evita pedir correo y el límite de envíos. |
| Cursor solo revisa y planifica | Claude implementa; Cursor valida con Playwright. |
| AdSense (no Ad Manager) para empezar | Entrada más sencilla para un sitio pequeño. |
| Sombras del visor solo en portada/contraportada | Los giros centrales no deben animar la sombra; la animación solo tiene sentido al inicio y al fin del libro. |
| Tiempos de sombra según el easing del giro (33 % / 80–88 %) | El 15 % y 95 % del movimiento visual no coinciden con el 15 % y 95 % del tiempo por la curva de aceleración. |

---

## 📦 Cómo continuar en un nuevo chat

```
Continuación de GrandBrandView. Lee STATE.md primero.
Stack: Vite 5 + React 18 + TS + Supabase + React Router v6 + Tailwind + Iconify.
Ramas: diseno → dev → produccion (Vercel publica produccion).
Puerto de desarrollo: 3000.
Cursor es el QA con Playwright. Claude implementa.

Tarea de esta sesión: [descripción]
```
