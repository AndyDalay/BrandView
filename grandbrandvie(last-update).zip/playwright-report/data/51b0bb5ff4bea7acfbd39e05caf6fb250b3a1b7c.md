# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: delete.spec.ts >> Borrado en la galería >> confirmar borra un manual local
- Location: tests\e2e\delete.spec.ts:38:3

# Error details

```
Error: page.evaluate: null
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - link "Ir a la galería" [ref=e5]:
      - /url: /
      - img "Andy Brand" [ref=e6]
    - button "Añadir manual" [ref=e9] [cursor=pointer]
  - main [ref=e15]:
    - generic [ref=e16]:
      - heading "Manuales de marca" [level=1] [ref=e17]
      - paragraph [ref=e18]: Desliza hacia los lados o usa la rueda del ratón. Arrastra un manual para cambiar su orden.
    - generic [ref=e21]:
      - generic [ref=e22]:
        - generic [ref=e24]:
          - link [ref=e25]:
            - /url: /manual/local-mw4iy7lo-bvj7k
            - generic [ref=e26]:
              - img "Portada T Mobile 2022" [ref=e27]
              - generic:
                - generic:
                  - paragraph: T Mobile 2022
                  - paragraph: 40 PÁGINAS
          - button "Ocultar T Mobile 2022" [ref=e28] [cursor=pointer]
        - generic [ref=e36]:
          - link [ref=e37]:
            - /url: /manual/local-mw4iv6ko-sj9yr
            - generic [ref=e38]:
              - img "Portada MANUAL DE MARCA GOLDEN BULLS" [ref=e39]
              - generic:
                - generic:
                  - paragraph: MANUAL DE MARCA GOLDEN BULLS
                  - paragraph: 19 PÁGINAS
          - button "Ocultar MANUAL DE MARCA GOLDEN BULLS" [ref=e40] [cursor=pointer]
      - generic [ref=e49]:
        - link [ref=e50]:
          - /url: /manual/manual-alta
          - generic [ref=e51]:
            - img "Portada Manual alto" [ref=e52]
            - generic:
              - generic:
                - paragraph: Manual alto
                - paragraph: 3 PÁGINAS
        - button "Ocultar Manual alto" [ref=e53] [cursor=pointer]
      - generic [ref=e62]:
        - link [ref=e63]:
          - /url: /manual/ejemplo-marca
          - generic [ref=e64]:
            - img "Portada Ejemplo Marca" [ref=e65]
            - generic:
              - generic:
                - paragraph: Ejemplo Marca
                - paragraph: 15 PÁGINAS
        - button "Ocultar Ejemplo Marca" [ref=e66] [cursor=pointer]
      - generic [ref=e75]:
        - link [ref=e76]:
          - /url: /manual/manual-alta
          - generic [ref=e77]:
            - img "Portada Manual alto" [ref=e78]
            - generic:
              - generic:
                - paragraph: Manual alto
                - paragraph: 3 PÁGINAS
        - button "Ocultar Manual alto" [ref=e79] [cursor=pointer]
      - generic [ref=e86]:
        - generic [ref=e88]:
          - link [ref=e89]:
            - /url: /manual/manual-baja
            - generic [ref=e90]:
              - img "Portada Manual bajo" [ref=e91]
              - generic:
                - generic:
                  - paragraph: Manual bajo
                  - paragraph: 3 PÁGINAS
          - button "Ocultar Manual bajo" [ref=e92] [cursor=pointer]
        - generic [ref=e100]:
          - link [ref=e101]:
            - /url: /manual/manual-cuadrada
            - generic [ref=e102]:
              - img "Portada Manual cuadrado" [ref=e103]
              - generic:
                - generic:
                  - paragraph: Manual cuadrado
                  - paragraph: 3 PÁGINAS
          - button "Ocultar Manual cuadrado" [ref=e104] [cursor=pointer]
      - generic [ref=e111]:
        - generic [ref=e113]:
          - link [ref=e114]:
            - /url: /manual/manual-de-prueba
            - generic [ref=e115]:
              - img "Portada Manual de prueba" [ref=e116]
              - generic:
                - generic:
                  - paragraph: Manual de prueba
                  - paragraph: 15 PÁGINAS
          - button "Ocultar Manual de prueba" [ref=e117] [cursor=pointer]
        - generic [ref=e125]:
          - link [ref=e126]:
            - /url: /manual/manual-horizontal
            - generic [ref=e127]:
              - img "Portada Manual horizontal" [ref=e128]
              - generic:
                - generic:
                  - paragraph: Manual horizontal
                  - paragraph: 3 PÁGINAS
          - button "Ocultar Manual horizontal" [ref=e129] [cursor=pointer]
      - generic [ref=e138]:
        - link [ref=e139]:
          - /url: /manual/otra-marca
          - generic [ref=e140]:
            - img "Portada Otra Marca" [ref=e141]
            - generic:
              - generic:
                - paragraph: Otra Marca
                - paragraph: 3 PÁGINAS
        - button "Ocultar Otra Marca" [ref=e142] [cursor=pointer]
```

# Test source

```ts
  1  | import { type Page } from '@playwright/test'
  2  | 
  3  | // Mismos nombres que usa src/lib/db.ts. Si cambian allí, cambian aquí.
  4  | const DB_NAME = 'grandbrandview'
  5  | const STORE = 'manuales'
  6  | 
  7  | /**
  8  |  * Inserta un manual local en IndexedDB para poder probar el borrado real.
  9  |  * Hay que llamarlo estando ya en el origen de la app (p. ej. tras page.goto('/')).
  10 |  */
  11 | export async function seedLocalManual(page: Page, id: string, nombre: string) {
> 12 |   await page.evaluate(
     |              ^ Error: page.evaluate: null
  13 |     async ({ id, nombre, DB_NAME, STORE }) => {
  14 |       const db: IDBDatabase = await new Promise((resolve, reject) => {
  15 |         const req = indexedDB.open(DB_NAME, 1)
  16 |         req.onupgradeneeded = () => {
  17 |           if (!req.result.objectStoreNames.contains(STORE)) {
  18 |             req.result.createObjectStore(STORE, { keyPath: 'id' })
  19 |           }
  20 |         }
  21 |         req.onsuccess = () => resolve(req.result)
  22 |         req.onerror = () => reject(req.error)
  23 |       })
  24 |       const svg = (fill: string) =>
  25 |         new Blob(
  26 |           [`<svg xmlns="http://www.w3.org/2000/svg" width="300" height="420"><rect width="300" height="420" fill="${fill}"/></svg>`],
  27 |           { type: 'image/svg+xml' },
  28 |         )
  29 |       const paginas = [
  30 |         { blob: svg('#225dff'), w: 300, h: 420 },
  31 |         { blob: svg('#ffffff'), w: 300, h: 420 },
  32 |         { blob: svg('#ffffff'), w: 300, h: 420 },
  33 |       ]
  34 |       await new Promise<void>((resolve, reject) => {
  35 |         const tx = db.transaction(STORE, 'readwrite')
  36 |         tx.objectStore(STORE).put({ id, nombre, createdAt: Date.now(), paginas })
  37 |         tx.oncomplete = () => resolve()
  38 |         tx.onerror = () => reject(tx.error)
  39 |       })
  40 |       db.close()
  41 |     },
  42 |     { id, nombre, DB_NAME, STORE },
  43 |   )
  44 | }
  45 | 
  46 | /** Borra el manual local sembrado. Tolerante a errores: se usa en afterEach. */
  47 | export async function removeLocalManual(page: Page, id: string) {
  48 |   await page.evaluate(
  49 |     async ({ id, DB_NAME, STORE }) => {
  50 |       try {
  51 |         const db: IDBDatabase = await new Promise((resolve, reject) => {
  52 |           const req = indexedDB.open(DB_NAME, 1)
  53 |           req.onsuccess = () => resolve(req.result)
  54 |           req.onerror = () => reject(req.error)
  55 |         })
  56 |         if (db.objectStoreNames.contains(STORE)) {
  57 |           await new Promise<void>((resolve) => {
  58 |             const tx = db.transaction(STORE, 'readwrite')
  59 |             tx.objectStore(STORE).delete(id)
  60 |             tx.oncomplete = () => resolve()
  61 |             tx.onerror = () => resolve()
  62 |           })
  63 |         }
  64 |         db.close()
  65 |       } catch {
  66 |         /* sin IndexedDB disponible: nada que limpiar */
  67 |       }
  68 |     },
  69 |     { id, DB_NAME, STORE },
  70 |   )
  71 | }
  72 | 
```