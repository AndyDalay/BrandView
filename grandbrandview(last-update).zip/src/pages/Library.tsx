import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Icon } from '@iconify/react';
import { Header } from '../components/Header';
import { ActionsStagger } from '../components/ActionsStagger';
import { AddManualModal } from '../components/AddManualModal';
import { HorizontalMasonry, type Pin, type PlacedPin } from '../components/HorizontalMasonry';
import { deleteManual } from '../lib/db';
import { deleteSharedManual } from '../lib/share';
import { getOrden, hideManual, loadGallery, ordenar, saveOrden, type Gallery, type Manual } from '../lib/gallery';
import { useTransition } from '../lib/useTransition';
import { ConfirmDeleteModal } from '../components/ConfirmDeleteModal';
import { Button } from '../components/ui/Button';
import { ShareModal } from '../components/ShareModal';
import { useMediaQuery } from '../lib/useMediaQuery';

const PIN_EXIT_MS = 1400; // tiempo que tardan los manuales en caer + limpiar textos

function laneHeight() {
  return Math.max(280, Math.round(window.innerHeight * 0.67));
}

// Mismo margen lateral que los textos (px-5 en móvil, md:px-10 en escritorio)
function gutterPx() {
  return window.innerWidth >= 768 ? 40 : 20;
}

export function Library() {
  const { exiting, go } = useTransition();
  const [data, setData] = useState<Gallery | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [lane, setLane] = useState(laneHeight);
  const [inset, setInset] = useState(gutterPx);
  const [adding, setAdding] = useState(false);
  const [intro, setIntro] = useState(true);
  const [orden, setOrden] = useState<string[]>(getOrden);
  const [pendingDelete, setPendingDelete] = useState<Manual | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [compartiendo, setCompartiendo] = useState<Manual | null>(null);
  const esMovil = useMediaQuery('(max-width: 639px)'); // móvil: botón Añadir flotante y menú de opciones en cada manual

  const reload = useCallback(() => {
    loadGallery()
      .then(setData)
      .catch((e: Error) => setError(e.message));
  }, []);

  useEffect(() => {
    reload();
  }, [reload]);

  useEffect(() => {
    const onResize = () => {
      setLane(laneHeight());
      setInset(gutterPx());
    };
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  useEffect(() => {
    const t = window.setTimeout(() => setIntro(false), 1600);
    return () => window.clearTimeout(t);
  }, []);

  // Manuales en el orden que eligió el usuario arrastrando
  const manuales = useMemo(() => ordenar(data?.manuales ?? [], orden), [data, orden]);
  const byId = useMemo(() => new Map(manuales.map((m) => [m.id, m])), [manuales]);
  const pins: Pin[] = useMemo(() => manuales.map((m) => ({ id: m.id, w: m.portadaW, h: m.portadaH })), [manuales]);

  // En vivo mientras se arrastra (no se guarda hasta soltar)
  const handleMove = useCallback((ids: string[]) => setOrden(ids), []);
  const handleDrop = useCallback((ids: string[]) => {
    setOrden(ids);
    saveOrden(ids);
  }, []);

  // La papelera abre el modal de confirmación propio de la app
  const handleDelete = useCallback((m: Manual) => setPendingDelete(m), []);

  const performDelete = useCallback(
    async (m: Manual) => {
      setDeleting(true);
      try {
        if (m.local) await deleteManual(m.id);
        else if (m.remoto) await deleteSharedManual(m.id);
        else hideManual(m.id);
        const next = orden.filter((id) => id !== m.id);
        setOrden(next);
        saveOrden(next);
        reload();
      } catch (e) {
        setError(e instanceof Error ? e.message : 'No se pudo borrar el manual.');
      } finally {
        setDeleting(false);
        setPendingDelete(null);
      }
    },
    [orden, reload]
  );

  const cancelDelete = useCallback(() => {
    if (!deleting) setPendingDelete(null);
  }, [deleting]);

  const open = (m: Manual) => go(`/manual/${encodeURIComponent(m.id)}`, PIN_EXIT_MS);

  const textCls = exiting ? 'anim-out' : 'anim-in';
  const textDelay = exiting ? { animationDelay: '1100ms' } : { animationDelay: '150ms' };

  return (
    <>
      <Header>
        <ActionsStagger exiting={exiting}>
          {!esMovil && (
            <Button icono="solar:add-circle-linear" onClick={() => setAdding(true)} data-testid="add-manual-button">
              Añadir manual
            </Button>
          )}
        </ActionsStagger>
      </Header>

      {/* Móvil: botón flotante abajo a la derecha, al alcance del pulgar. Fuera del header porque el header tiene backdrop-filter */}
      {esMovil && (
        <Button
          icono="solar:add-circle-linear"
          tamano="lg"
          pill
          onClick={() => setAdding(true)}
          data-testid="add-manual-button"
          aria-label="Añadir manual"
          className="fixed bottom-6 right-5 z-40 shadow-xl"
        >
          Añadir
        </Button>
      )}


      <main data-testid="library-page" className="relative z-10 w-full px-5 py-10 md:px-10">
        <div className={textCls} style={textDelay}>
          <h1 className="font-display text-3xl text-azul-dark md:text-4xl">Manuales de marca</h1>
          <p className="mt-2 text-gris-txt-oscuro">
            Desliza hacia los lados o usa la rueda del ratón. Arrastra un manual para cambiar su orden.
          </p>

          {error && <p className="mt-8 text-terracota">{error}</p>}

          {data && data.manuales.length === 0 && (
            <p className="mt-8 rounded-lg border border-dashed border-gris-line bg-white/60 p-6 text-gris-txt-oscuro">
              No hay manuales todavía. Pulsa <strong>Añadir manual</strong> para subir un PDF o una carpeta.
            </p>
          )}
        </div>

        {pins.length > 0 && (
          <div className="-mx-5 mt-8 md:-mx-10" data-testid="gallery">
            <HorizontalMasonry
              pins={pins}
              height={lane}
              inset={inset}
              exiting={exiting}
              intro={intro}
              onMove={handleMove}
              onDrop={handleDrop}
              renderPin={(p: PlacedPin) => (
                <PinCard
                  manual={byId.get(p.id) as Manual}
                  pin={p}
                  onOpen={open}
                  onDelete={handleDelete}
                  onShare={setCompartiendo}
                />
              )}
            />
          </div>
        )}
      </main>

      {compartiendo && <ShareModal manual={compartiendo} onClose={() => setCompartiendo(null)} />}

      {pendingDelete && (
        <ConfirmDeleteModal
          nombre={pendingDelete.nombre}
          tipo={pendingDelete.local ? 'local' : pendingDelete.remoto ? 'remoto' : 'base'}
          busy={deleting}
          onCancel={cancelDelete}
          onConfirm={() => performDelete(pendingDelete)}
        />
      )}

      {adding && (
        <AddManualModal
          onClose={() => setAdding(false)}
          onAdded={() => {
            setAdding(false);
            reload();
          }}
        />
      )}
    </>
  );
}

function PinCard({
  manual,
  pin,
  onOpen,
  onDelete,
  onShare,
}: {
  manual: Manual;
  pin: PlacedPin;
  onOpen: (m: Manual) => void;
  onDelete: (m: Manual) => void;
  onShare: (m: Manual) => void;
}) {
  const [menuAbierto, setMenuAbierto] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const borrable = manual.local || manual.remoto;

  // El menú móvil se cierra al tocar fuera
  useEffect(() => {
    if (!menuAbierto) return;
    const fuera = (e: PointerEvent) => {
      if (!menuRef.current?.contains(e.target as Node)) setMenuAbierto(false);
    };
    document.addEventListener('pointerdown', fuera);
    return () => document.removeEventListener('pointerdown', fuera);
  }, [menuAbierto]);

  return (
    <div className="group relative h-full w-full transition-transform duration-300 ease-out hover:-translate-y-2">
      <a
        data-testid="manual-card"
        data-manual-id={manual.id}
        href={`/manual/${encodeURIComponent(manual.id)}`}
        draggable={false}
        onClick={(e) => {
          e.preventDefault();
          onOpen(manual);
        }}
        className="block h-full w-full"
      >
        <div className="relative h-full w-full rounded-md transition-shadow duration-300 ease-out group-hover:shadow-[0_22px_44px_-16px_rgba(18,34,79,0.55)]">
          <img
            src={manual.portada}
            alt={`Portada ${manual.nombre}`}
            width={pin.dw}
            height={pin.dh}
            loading="lazy"
            draggable={false}
            className="h-full w-full rounded-md bg-white object-cover"
          />

          {/* Degradado negro cenizo con grano: corto y translúcido, solo para que el texto blanco se lea */}
          <div className="pointer-events-none absolute inset-0 overflow-hidden rounded-md opacity-0 transition-opacity duration-300 group-hover:opacity-100">
            <div className="absolute inset-x-0 bottom-0 h-[64px] bg-gradient-to-t from-negro to-negro/40" />
            <div className="grain absolute inset-0" />
            <div className="absolute inset-x-0 bottom-0 p-3">
              <p className="font-display text-base text-white">{manual.nombre}</p>
              <p className="font-label text-[10px] tracking-[0.16em] text-white/80">{manual.paginas.length} PÁGINAS</p>
            </div>
          </div>

          {/* Punto azul brillante: manual subido y todavía no abierto */}
          {manual.nuevo && (
            <span className="pointer-events-none absolute right-2.5 top-2.5 z-10 h-3 w-3 animate-pulse rounded-full bg-azul shadow-[0_0_0_3px_rgb(255, 255, 255),0_0_14px_5px_rgb(34, 93, 255)]" />
          )}
        </div>
      </a>

      {/* Móvil: opciones (⋯). Se abre con un toque y muestra Compartir y Eliminar */}
      <div ref={menuRef} className="absolute right-0 top-0 z-20 sm:hidden">
        <button
          type="button"
          data-testid="manual-options"
          aria-label={`Opciones de ${manual.nombre}`}
          aria-haspopup="menu"
          aria-expanded={menuAbierto}
          onPointerDown={(e) => e.stopPropagation()}
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            setMenuAbierto((o) => !o);
          }}
          className="grid h-9 w-9 place-items-center rounded-bl-xl rounded-tr-md bg-white text-azul-dark shadow-md"
        >
          <Icon icon="solar:menu-dots-linear" width={18} />
        </button>
        {menuAbierto && (
          <div role="menu" data-testid="manual-options-menu" className="absolute right-0 top-10 w-40 rounded-xl border border-gris-line bg-white p-1 shadow-xl">
            <button
              type="button"
              role="menuitem"
              data-testid="manual-options-share"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setMenuAbierto(false);
                onShare(manual);
              }}
              className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm text-azul-dark hover:bg-azul-tint"
            >
              <Icon icon="solar:share-linear" width={18} />
              Compartir
            </button>
            <button
              type="button"
              role="menuitem"
              data-testid="manual-options-delete"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setMenuAbierto(false);
                onDelete(manual);
              }}
              className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm text-terracota hover:bg-azul-tint"
            >
              <Icon icon="solar:trash-bin-minimalistic-linear" width={18} />
              {borrable ? 'Eliminar' : 'Ocultar'}
            </button>
          </div>
        )}
      </div>

      {/* Escritorio: borrar en la esquina superior derecha, visible al pasar el ratón */}
      <button
        type="button"
        data-testid="manual-delete"
        title={borrable ? 'Borrar manual' : 'Ocultar manual'}
        aria-label={`${borrable ? 'Borrar' : 'Ocultar'} ${manual.nombre}`}
        onPointerDown={(e) => e.stopPropagation()}
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          onDelete(manual);
        }}
        className="absolute right-0 top-0 z-20 hidden h-9 w-9 place-items-center rounded-bl-xl rounded-tr-md bg-white text-terracota opacity-0 shadow-md transition-all duration-200 ease-out hover:bg-terracota hover:text-white focus-visible:opacity-100 group-hover:opacity-100 sm:grid"
      >
        <Icon icon="solar:trash-bin-minimalistic-linear" width={18} />
      </button>
    </div>
  );
}
